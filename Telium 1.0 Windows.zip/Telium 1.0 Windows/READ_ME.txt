Telium
This game was created as a my first Yr12 project for my Computer Science A-Level. 
It was supposed to be a text-based game, made in python, however I decided that I would set the bar with my first project. 
I ended up using Unity and C# as I'd made games using these before. I opted for GUI based as given the time frame,
I figured that going full top-down style would too time consuming and I would spend hours just looking for the right assets. 

All the assets used in this project were made by me, appart from the Horses which where made by one of my friend's. 
Said friend also lent some advice on fixing some of the bugs that were present in the orginal version, so shout out to him. 

Anyway, all the features of this game should be working, if you have any questions or find any bugs please let me know. 

Enjoy the game!

Instructions:
Run the "Telium.exe" File to run the game, it should load up. Select your display resolution, graphic settings, 
display and whether you would like to play the game windowed. Press play to run the game, 
all the instrutions on how to play the game are built in, and can be found by selecting "How to Play" on the main menu. 
At any point while playing the game, you can use the "Esc" key to pause, and quit the game. 

This version is designed for Windows 10 64-bit and was made using Unity Version 2021.2.8f1 and Visual Studio 2019. 